document.querySelector(".login-section-container-options-old-checkbox").addEventListener("click", function (evt) {
  document.querySelector(".login-section-container-options-checkbox-wrapper").classList.toggle("active-label")
});